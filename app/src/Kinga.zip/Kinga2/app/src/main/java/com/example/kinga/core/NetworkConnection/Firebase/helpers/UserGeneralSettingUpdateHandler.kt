package com.example.kinga.core.NetworkConnection.Firebase.helpers

import android.content.Context
import com.example.kinga.core.userUtils.SessionHandler

class UserGeneralSettingUpdateHandler(
    var context: Context,
    var data: Map<String, String>,
){
    fun update(){
        val session = SessionHandler(context)

        session.setUserGeneralSettings(
            enableShifts = data["enable_shifts"].toBoolean(),
                enableOpenTickets = data["enable_open_tickets"].toBoolean(),
                enableLowStockNotifications = data["enable_low_stock_notifications"].toBoolean(),
                enableNegativeStockAlerts = data["enable_negative_stock_alerts"].toBoolean(),
            )
    }
}