package com.example.kinga.core;

import android.annotation.SuppressLint;
import android.content.Context;

import com.example.kinga.R;

import java.text.SimpleDateFormat;
import java.util.HashMap;

public class AppSettings {
    public static final boolean PRODUCTION = false;
    public static final boolean TESTING = false;


    public static final String PRIMARY_RECEIPT_NAME = "primary";

    /**
     * Specifies the amount of time in millis view should wait deleting object from db
     */
    public static final int MS_DELAY_AFTER_MODEL_DB_DELETE = 1000;


    public static String EMPTY_PRICE_REPRESENTATION = "0.00";
    public static String SHIFT_MODEL_RELOAD_REQUEST_KEY = "ShiftModelHasChanged";
    public static String SHIFT_MODEL_RELOAD_bundle_KEY = "ShiftModelBundleKey";

    // Transaction type constants
    public static final int MONEY_TRANS = 0;
    public static final int DEBT_TRANS = 1;
    public static final int LOYALTY_TRANS = 2;
    public static final int MULTIPLE_TRANS = 3;


    // Payment constants
    public static final int CASH_TYPE = 0;
    public static final int MPESA_TYPE = 1;
    public static final int CARD_TYPE = 2;
    public static final int POINTS_TYPE = 3;
    public static final int DEBT_TYPE = 4;
    public static final int OTHER_TYPE = 5;

    public static HashMap<Integer, String> getPaymentTypes(){

        HashMap<Integer, String> paymentTypes = new HashMap<>();

        paymentTypes.put(CASH_TYPE, "Cash");
        paymentTypes.put(MPESA_TYPE, "Mpesa");
        paymentTypes.put(CARD_TYPE, "Card");
        paymentTypes.put(POINTS_TYPE, "Points");
        paymentTypes.put(DEBT_TYPE, "Debt");
        paymentTypes.put(OTHER_TYPE, "Other");

        return paymentTypes;

    }



    // Date formatters
    @SuppressLint("SimpleDateFormat")
    SimpleDateFormat FULL_DATE_FORMATTER = new SimpleDateFormat(
            "EEEE, d MMMM yyyy"
    );

    @SuppressLint("SimpleDateFormat")
    SimpleDateFormat TIME_FORMATTER = new SimpleDateFormat("hh:mm aa");


}
