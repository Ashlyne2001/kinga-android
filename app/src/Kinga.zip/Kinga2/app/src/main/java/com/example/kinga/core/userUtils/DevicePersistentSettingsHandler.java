package com.example.kinga.core.userUtils;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * A class that handles the user's session
 */
public class DevicePersistentSettingsHandler {

    private static final String PREF_NAME = "DevicePersistentSettings";
    private static final String KEY_USE_CAMERA_FOR_BARCODE = "use_camera_for_barcode";

    private final SharedPreferences.Editor mEditor;
    private final SharedPreferences mPreferences;

    @SuppressLint("CommitPrefEdits")
    public DevicePersistentSettingsHandler(Context context) {
        mPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();
    }

    /**
     * @param useCameraForBarcode - A flag indicating if camera should be used for barcodes
     */
    public void setCameraForBarcode(boolean useCameraForBarcode) {
        mEditor.putBoolean(KEY_USE_CAMERA_FOR_BARCODE, useCameraForBarcode);
        mEditor.commit();
    }

    /**
     * @return - A flag indicating if camera should be used for barcodes
     */
    public boolean getCameraForBarcode() {
        return mPreferences.getBoolean(KEY_USE_CAMERA_FOR_BARCODE, false);
    }

}
