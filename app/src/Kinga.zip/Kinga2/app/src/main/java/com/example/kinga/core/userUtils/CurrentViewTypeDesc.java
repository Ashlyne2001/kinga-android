package com.example.kinga.core.userUtils;



public class CurrentViewTypeDesc {



}
