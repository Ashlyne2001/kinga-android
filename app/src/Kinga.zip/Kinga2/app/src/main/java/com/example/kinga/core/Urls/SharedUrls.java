package com.example.kinga.core.Urls;

public class SharedUrls {

    //private static String mHostAddress = "10.0.2.2:8000";
//    private static String mHostAddress = "192.168.0.16:8000";
    //private static String mHostAddress = "f575ba77ad33.ngrok.io";
    //http://721d2b02.ngrok.io

    public static String backOfficeUrl = "https://developers.google.com/ml-kit";
    public static String helpPageUrl = "https://www.tabnine.com/?utm_source=search-web";


    public static String getBaseUrl() {

//        return "https://portal.traqsale.com";
        return "http://192.168.100.10:8000";
        /*
        if (MySettings.PRODUCTION) {
            Log.d("mylog", "Using Production");
            return "https://backoffice.traqsale.com/";
        } else {
            Log.d("mylog", "Using Dev");
            return "http://192.168.0.16:8000";
        }

         */
    }



    public static String loginUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/pos/api-token-auth/");
    }

    public static String LogoutUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/pos/logout/");
    }

    public static String signUpUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/signup/");
    }

    public static String changePasswordUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/password/change/");
    }

    public static String contactUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/contact/");
    }

    // Profile urls
    public static String profileViewUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/profile/");
    }

    // Shift urls
    public static String shiftCreateViewUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/stores/shifts/");
    }

    // Receipt urls
    public static String receiptCreateUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/pos/receipts/", storeRegNo);
    }

    public static String receiptCompleteUrl(String storeRegNo, String regNo) {
        return String.format
                ("%s%s%s/%s/", getBaseUrl(), "/api/pos/receipts/payment/", storeRegNo, regNo);
    }

    public static String receiptRefundUrl(String storeRegNo, String regNo) {
        return String.format
                ("%s%s%s/%s/", getBaseUrl(), "/api/pos/receipts/refund/", storeRegNo, regNo);
    }

    // Receipt urls
    public static String receiptSendEmail() {
        return String.format("%s%s", getBaseUrl(), "/api/email-receipt/");
    }


















    public static String profileEditUrl() {
        return SharedUrls.profileViewUrl();
    }

    public static String profilePicUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/profile/picture/edit/");
    }

    // Notification urls
    public static String notificationIndexUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/notifications/");
    }

    public static String notificationViewUrl(String notificationRegNo) {
        return String.format(
                "%s%s%s/", getBaseUrl(), "/api/notifications/", notificationRegNo);
    }

    // Billing urls
    public static String billingPaymentForMultipleTrackersPaymentUrl() {
        return String.format("%s%s/", getBaseUrl(), "/api/billing/payment_for_all_trackers/pay");
    }

    public static String billingPaymentForSingleTrackerPaymentUrl(String trackerRegNo) {
        return String.format(
                "%s%s%s/", getBaseUrl(), "/api/billing/payment_for_single_tracker/pay/", trackerRegNo);
    }

    //*** Store urls
    public static String storeIndexUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/stores/");
    }

    public static String trackerViewUrl(String tracker_reg_no) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/trackers/", tracker_reg_no);
    }

    // Payment urls
    public static String billingPricingForSingleStoreViewUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/tp/billing/pricing_for_single_store/", storeRegNo);
    }

    public static String billingPaymentForSingleStorePaymentUrl(String storeRegNo, String period) {
        return String.format(
                "%s%s%s/%s/", getBaseUrl(), "/api/tp/billing/payment_for_single_store/pay/", storeRegNo,  period);
    }

    public static String billingPricingForMultipleStoresViewUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/tp/billing/payment_for_all_stores/");
    }

    public static String billingPaymentForMultipleStoresPaymentUrl(String period) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/tp/billing/payment_for_all_stores/pay/", period);
    }

    // Categories urls
    public static String categoryIndexViewUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/store/category/", storeRegNo);
    }

    // Staff urls
    public static String staffIndexViewUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/store/staff/", storeRegNo);
    }

    // Customer urls
    public static String customerIndexViewUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/store/customer/", storeRegNo);
    }

    public static String customerDebtorsIndexViewUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/store/customer/debtors/", storeRegNo);
    }

    public static String customerViewUrl(String customerRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/customer/", customerRegNo);
    }

    // Closed cash urls
    public static String closedCashIndexViewUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/store/closed_cash/", storeRegNo);
    }

    public static String closedCashViewUrl(String closedCashRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/closed_cash/", closedCashRegNo);
    }

    // Products urls
    public static String productIndexViewUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/store/products/", storeRegNo);
    }

    public static String productViewUrl(String productRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/products/", productRegNo);
    }

    // Tickets urls
    public static String ticketIndexTodayUrl(String storeRegNo) {
        return String.format("%s/api/store/tickets/today/%s/", getBaseUrl(), storeRegNo);
    }

    public static String ticketIndexWeekUrl(String storeRegNo) {
        return String.format("%s/api/store/tickets/week/%s/", getBaseUrl(), storeRegNo);
    }

    public static String ticketIndexMonthUrl(String storeRegNo) {
        return String.format("%s/api/store/tickets/month/%s/", getBaseUrl(), storeRegNo);
    }

    public static String ticketIndexAllTimeUrl(String storeRegNo) {
        return String.format("%s/api/store/tickets/all_time/%s/", getBaseUrl(), storeRegNo);
    }

    public static String ticketViewUrl(String ticketRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/tickets/", ticketRegNo);
    }

    public static String fcmTokenUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/fcm/");
    }

}
