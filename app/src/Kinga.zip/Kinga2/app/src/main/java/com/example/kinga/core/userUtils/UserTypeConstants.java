package com.example.kinga.core.userUtils;

public class UserTypeConstants {

    public static final int TOP_USER = 1;
    public static final int MANAGER_USER = 2;
    public static final int CASHIER_USER = 3;

}
