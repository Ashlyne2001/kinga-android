package com.example.kinga.core.NetworkConnection.ConnectionHelpers;

/**
 * An interface that for connection broadcast
 */
public interface MyConnectionBroadcastInterface {

    /**
     * Activates Connection listening broadcast
     */
    void activateConnectionBroadcast();

    /**
     * Deactivates Connection listening broadcast
     */
    void deactivateConnectionBroadcast();

}
