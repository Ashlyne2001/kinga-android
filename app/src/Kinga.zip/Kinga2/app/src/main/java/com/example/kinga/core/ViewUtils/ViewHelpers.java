package com.example.kinga.core.ViewUtils;

import androidx.appcompat.app.AppCompatActivity;

public class ViewHelpers {

    /**
     * Changes the status bar color to white and system ui visibility to dark
     * @param activity (AppCompatActivity)
     */
    static public void changeStatusBarColor(AppCompatActivity activity){
//        Window window = activity.getWindow();
//        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
//        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//        window.setStatusBarColor(activity.getResources().getColor(R.color.white));
//
//        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    static public void changeToolbarColor(AppCompatActivity activity){

        // Define ActionBar object
//        ActionBar actionBar;
//        actionBar = activity.getSupportActionBar();
//
//        // Define ColorDrawable object and parse color
//        // using parseColor method
//        // with color hash code as its parameter
//        ColorDrawable colorDrawable
//                = new ColorDrawable(Color.parseColor("#FFFFFF"));
//
//        // Set BackgroundDrawable
//        actionBar.setBackgroundDrawable(colorDrawable);
//        actionBar.setElevation(0);


    }
}
