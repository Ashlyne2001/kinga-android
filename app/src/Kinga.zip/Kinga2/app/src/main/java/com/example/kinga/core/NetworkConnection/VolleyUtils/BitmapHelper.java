package com.example.kinga.core.NetworkConnection.VolleyUtils;

import android.graphics.Bitmap;

import java.io.ByteArrayOutputStream;

public class BitmapHelper {

    /**
     * Turn bitmap into byte array.
     *
     * @param bitmap data
     * @return byte array
     */
    public static byte[] getByteArrayFromBitmap(Bitmap bitmap) {

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
}
