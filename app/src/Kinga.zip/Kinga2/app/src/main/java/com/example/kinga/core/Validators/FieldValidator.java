package com.example.kinga.core.Validators;

import android.content.Context;
import android.widget.EditText;

import com.example.kinga.R;

public class FieldValidator {

    private static final String KEY_EMPTY = "";

    // Validate name
    public static boolean validateNameField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Name",
                editText,
                ApiModelsMaxLength.sNameMaxLength,
                isRequired
        );
    }


    // Validate contact message
    public static boolean validateContactMessageField(Context context, EditText editText){

        return FieldValidator.validateStringFieldLength(
                context,
                "Message",
                editText,
                ApiModelsMaxLength.sContactMessageTextMaxLength,
                true
        );
    }

    // Validate first name
    public static boolean validateFirstNameField(Context context, EditText editText){

        return FieldValidator.validateStringFieldLength(context,
                "First name",
                editText,
                ApiModelsMaxLength.sUserFirstNameMaxLength,
                true
        );
    }

    // Validate last name
    public static boolean validateLastNameField(Context context, EditText editText){

        return FieldValidator.validateStringFieldLength(
                context,
                "Last name",
                editText,
                ApiModelsMaxLength.sUserLastNameMaxLength,
                true
        );
    }

    // Validate email
    public static boolean validateEmailField(Context context, EditText editText, boolean isRequired){

        String value = editText.getText().toString().toLowerCase().trim();
        String name = "Email";
        int maxLength = ApiModelsMaxLength.sUserEmailMaxLength;

        if (!isRequired && KEY_EMPTY.equals(value)){
            return true;
        }

        if(KEY_EMPTY.equals(value)){
            editText.setError(context.getResources().getString(R.string.field_cannot_be_empty, "Email"));
            editText.requestFocus();
            return false;
        }

        if(value.length() > maxLength){
            editText.setError(context.getResources().getString(R.string.field_string_too_long,
                    name,
                    maxLength));
            editText.requestFocus();
            return false;
        }


        if (!EmailValidator.isValidEmail(value)){
            editText.setError(context.getResources().getString(R.string.field_email_invalid));
            editText.requestFocus();
            return false;
        }

        return true;
    }

    // Validate phone
    public static boolean validatePhoneField(Context context, EditText editText, boolean isRequired){

        String value = editText.getText().toString().trim();

        if (!isRequired && KEY_EMPTY.equals(value)){
            return true;
        }

        // Phone validation
        if(KEY_EMPTY.equals(value)){
            editText.setError(context.getResources().getString(R.string.field_cannot_be_empty, "Phone"));
            editText.requestFocus();
            return false;
        }

        if(value.length() > ApiModelsMaxLength.sUserPhoneMaxLength){
            editText.setError(context.getResources().getString(R.string.field_phone_too_long));
            editText.requestFocus();
            return false;
        }

        if(value.length() < ApiModelsMaxLength.sUserPhoneMaxLength){
            editText.setError(context.getResources().getString(R.string.field_phone_too_short));
            editText.requestFocus();
            return false;
        }

        return true;

    }

    // Validate password1
    public static boolean validatePassword1Field(Context context, EditText editText){

        String value = editText.getText().toString().trim();
        // Passwords validation
        if(KEY_EMPTY.equals(value)){
            editText.setError(context.getResources().getString(R.string.field_password_empty));
            editText.requestFocus();
            return false;
        }

        if(value.length() < 8){
            editText.setError(context.getResources().getString(R.string.field_password_too_short));
            editText.requestFocus();
            return false;
        }

        if(value.length() > 30){
            editText.setError(context.getResources().getString(R.string.field_password_too_long));
            editText.requestFocus();
            return false;
        }

        return true;
    }

    // Validate password2
    public static boolean validatePassword2Field(Context context, EditText editText, String password1){

        String value = editText.getText().toString().trim();

        if(!value.equals(password1)){
            editText.setError(context.getResources().getString(R.string.field_passwords_mismatch));
            editText.requestFocus();
            return false;
        }

        return true;
    }

    // Validate business name
    public static boolean validateBusinessNameField(Context context, EditText editText){

        return FieldValidator.validateStringFieldLength(
                context,
                "Business name",
                editText,
                ApiModelsMaxLength.sUserBusinessNameMaxLength,
                true
        );
    }

    // Validate location
    public static boolean validateLocationField(Context context, EditText editText){

        return FieldValidator.validateStringFieldLength(
                context,
                "Location",
                editText,
                ApiModelsMaxLength.sUserLocationMaxLength,
                true
        );
    }

    // Validate tax name
    public static boolean validateTaxNameField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Name",
                editText,
                ApiModelsMaxLength.sTaxNameMaxLength,
                isRequired
        );
    }

    // Validate discount name
    public static boolean validateDiscountNameField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Name",
                editText,
                ApiModelsMaxLength.sDiscountNameMaxLength,
                isRequired
        );
    }

    // Validate category name
    public static boolean validateCategoryNameField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Name",
                editText,
                ApiModelsMaxLength.sCategoryNameMaxLength,
                isRequired
        );
    }

    // Validate category name
    public static boolean validateProductNameField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Name",
                editText,
                ApiModelsMaxLength.sProductNameMaxLength,
                isRequired
        );
    }

    // Validate amount
    public static boolean validateAmountField(Context context, EditText editText, boolean isRequired){
        return validatePriceField(
                context,
                "Amount",
                editText,
                isRequired
        );
    }

    // Validate comment
    public static boolean validateShiftCommentField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Comment",
                editText,
                ApiModelsMaxLength.sShiftCommentMaxLength,
                isRequired
        );
    }

    // Validate customer name
    public static boolean validateCustomerNameField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Name",
                editText,
                ApiModelsMaxLength.sCustomerNameMaxLength,
                isRequired
        );
    }

    // Validate address
    public static boolean validateAddressField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Address",
                editText,
                ApiModelsMaxLength.sAddressMaxLength,
                isRequired
        );
    }

    // Validate city
    public static boolean validateCityField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "City",
                editText,
                ApiModelsMaxLength.sCityMaxLength,
                isRequired
        );
    }

    // Validate region
    public static boolean validateRegionField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Region",
                editText,
                ApiModelsMaxLength.sRegionMaxLength,
                isRequired
        );
    }

    // Validate postal code
    public static boolean validatePostalCodeField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Postal code",
                editText,
                ApiModelsMaxLength.sPostalCodeMaxLength,
                isRequired
        );
    }

    // Validate country
    public static boolean validateCountryField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Country",
                editText,
                ApiModelsMaxLength.sCountryMaxLength,
                isRequired
        );
    }

    // Validate customer code
    public static boolean validateCustomerCodeField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Customer code",
                editText,
                ApiModelsMaxLength.sCustomerCodeMaxLength,
                isRequired
        );
    }

    // Validate sku
    public static boolean validateSkuField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Sku",
                editText,
                ApiModelsMaxLength.sSkuMaxLength,
                isRequired
        );
    }

    // Validate barcode
    public static boolean validateBarcodeField(Context context, EditText editText, boolean isRequired){

        return FieldValidator.validateStringFieldLength(
                context,
                "Barcode",
                editText,
                ApiModelsMaxLength.sBarcodeMaxLength,
                isRequired
        );
    }

    // Validate credit limit
    public static boolean validateCreditLimitField(Context context, EditText editText, boolean isRequired){
        return validatePriceField(
                context,
                "Credit limit",
                editText,
                isRequired
        );
    }

    // Validate price
    public static boolean validatePriceField(Context context, EditText editText, boolean isRequired){
        return validatePriceField(
                context,
                "Price",
                editText,
                isRequired
        );
    }

    // Validate cost
    public static boolean validateCostField(Context context, EditText editText, boolean isRequired){
        return validatePriceField(
                context,
                "Cost",
                editText,
                isRequired
        );
    }

    // Validate stock units
    public static boolean validateStockUnitsField(Context context, EditText editText, boolean isRequired){
        return validatePriceField(
                context,
                "Stock units",
                editText,
                isRequired
        );
    }

    // Validate quantity
    public static boolean validateQuantityField(Context context, EditText editText, boolean isRequired){

        return validateDigitFieldLength(
                context,
                "Quantity",
                editText,
                ApiModelsMaxLength.sQuantityUnitsMaxLength,
                isRequired
        );
    }

    // Validate credit limit
    private static boolean validatePriceField(
            Context context,
            String fieldName,
            EditText editText,
            boolean isRequired){

        String errorText;
        int maxLength = ApiModelsMaxLength.sAmountMaxLength;

        String value = editText.getText().toString().trim();

        // Check if we should allow empty
        if (isRequired && KEY_EMPTY.equals(value)){
            editText.setError(context.getResources().getString(R.string.field_cannot_be_empty, fieldName));
            editText.requestFocus();
            return false;
        }

        // Check if it's a valid digit

        if (value.length() > 0){
            try {
                double d = Double.parseDouble(value);

                if (isRequired && d <= 0){
                    editText.setError(context.getResources().getString(R.string.field_digit_invalid));
                    editText.requestFocus();
                    return false;
                }
            } catch (NumberFormatException nfe) {
                editText.setError(context.getResources().getString(R.string.field_digit_invalid));
                editText.requestFocus();
                return false;
            }
        }





        // Check field length
        if(value.length() > maxLength){

            errorText = context.getResources().getString(
                    R.string.field_digit_too_long,
                    fieldName,
                    maxLength
            );

            editText.setError(errorText);
            editText.requestFocus();
            return false;
        }

        return true;
    }

    public static boolean validateValuePercentageField(Context context, EditText editText){
        return validatePercentageField(context, editText, "Value");
    }

    public static boolean validateRatePercentageField(Context context, EditText editText){
        return validatePercentageField(context, editText, "Rate");
    }

    // Validate percentage
    public static boolean validatePercentageField(Context context, EditText editText, String fieldName){

        String value = editText.getText().toString().trim();

        // Check if field is empty
        if(KEY_EMPTY.equals(value)){
            editText.setError(context.getResources().getString(R.string.field_cannot_be_empty, fieldName));
            editText.requestFocus();
            return false;
        }

        String text;
        // We use Float so tht we can be able to validate both integers and floats
        if(Float.parseFloat(value) == 0){

            text = context.getResources().getString(R.string.field_digit_cannot_be_zero,
                    fieldName,
                    0);

            editText.setError(text);

            editText.requestFocus();
            return false;

        }else if (Float.parseFloat(value) > 100){
            text = context.getResources().getString(R.string.field_digit_cannot_be_more_than,
                    fieldName,
                    100);

            editText.setError(text);

            editText.requestFocus();
            return false;
        }

        return true;
    }
    
    // Validate general string field
    public static boolean validateStringFieldLength(
            Context context, 
            String name, 
            EditText editText, 
            int maxLength,
            boolean isRequired){

        return validateLength(context, name, editText, maxLength, true, isRequired);
    }

    // Validate general digit field
    public static boolean validateDigitFieldLength(
            Context context, 
            String name, 
            EditText editText, 
            int maxLength,
            boolean isRequired){
        
        return validateLength(context, name, editText, maxLength, false, isRequired);
    }

    public static boolean validateLength(
            Context context,
            String name, 
            EditText editText,
            int maxLength, 
            boolean isString,
            boolean isRequired
    ){

        String text;
        if (isString){
            text = context.getResources().getString(R.string.field_string_too_long,
                                                                name,
                                                                maxLength);
        } else{
            text = context.getResources().getString(R.string.field_digit_too_long,
                    name,
                    maxLength);
        }

        String value = editText.getText().toString().trim();

        // Check if we should allow empty
        if (!isRequired && KEY_EMPTY.equals(value)){
            return true;
        }
        
        
        // Check if field is empty
        if(KEY_EMPTY.equals(value)){
            editText.setError(context.getResources().getString(R.string.field_cannot_be_empty, name));
            editText.requestFocus();
            return false;
        }

        // Check field length
        if(value.length() > maxLength){
            editText.setError(text);
            editText.requestFocus();
            return false;
        }

        // If its digit, check if it's not 0
        if(!isString){

            // We use Float so tht we can be able to validate both integers and floats
            if(Float.parseFloat(value) == 0){

                text = context.getResources().getString(R.string.field_digit_cannot_be_zero,
                        name,
                        0);

                editText.setError(text);

                editText.requestFocus();
                return false;
            }
        }

        return true;
    }


}
