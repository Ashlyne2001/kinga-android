package com.example.kinga.core.Urls;

import static com.example.kinga.core.Urls.SharedUrls.getBaseUrl;

public class EmployeeUrlResolver {

    // Category urls
    public static String epCategoryIndexUrl() {
        return String.format("%s%s", getBaseUrl(), "api/ep/pos/categories/");
    }

    public static String epCategoryCreateUrl() {
        return epCategoryIndexUrl();
    }

    public static String epCategoryViewUrl(String reg_no) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/ep/categories/edit/", reg_no);
    }

    // Discount urls
    public static String epDiscountIndexUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/ep/pos/discounts/", storeRegNo);
    }

    public static String epDiscountCreateUrl(String storeRegNo) {
        return epDiscountIndexUrl(storeRegNo);
    }

    public static String epDiscountViewUrl(String storeRegNo, String discountRegNo) {
        return String.format("%s%s%s/edit/%s/", getBaseUrl(), "/api/ep/pos/discounts/", storeRegNo, discountRegNo);
    }

    // Modifiers
    public static String epModifierIndexUrl(String reg_no) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/pos/ep/modifiers/", reg_no);
    }

    // Products
    public static String epProductIndexUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/pos/ep/products/", storeRegNo);
    }

    public static String epProductCreateUrl(String storeRegNo) {
        return epProductIndexUrl(storeRegNo);
    }

    public static String epProductViewUrl(String storeRegNo, String productRegNo) {
        return String.format("%s%s%s/edit/%s/", getBaseUrl(), "/api/pos/ep/products/", storeRegNo, productRegNo);
    }

    public static String epProductImageViewUrl(String storeRegNo, String productRegNo) {
        return String.format("%s%s%s/edit/image/%s/", getBaseUrl(), "/api/pos/ep/products/", storeRegNo, productRegNo);
    }

    // Tax urls
    public static String epTaxIndexUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/ep/pos/taxes/", storeRegNo);
    }

    public static String epTaxCreateUrl(String storeRegNo) {
        return epTaxIndexUrl(storeRegNo);
    }

    public static String epTaxViewUrl(String storeRegNo, String taxRegNo) {
        return String.format("%s%s%s/edit/%s/", getBaseUrl(), "/api/ep/pos/taxes/", storeRegNo, taxRegNo);
    }

    // Customer urls
    public static String epCustomerIndexUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/ep/pos/customers/");
    }

    public static String epCustomerCreateUrl() {
        return epCustomerIndexUrl();
    }

    public static String epCustomerViewUrl(String reg_no) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/ep/customers/", reg_no);
    }

    // Store urls
    public static String epLeanStoreIndexUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/ep/stores_with_receipt/lean/");
    }



}
