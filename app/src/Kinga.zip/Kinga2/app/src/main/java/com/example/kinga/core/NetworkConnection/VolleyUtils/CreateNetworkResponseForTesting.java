package com.example.kinga.core.NetworkConnection.VolleyUtils;

import com.android.volley.NetworkResponse;
import com.android.volley.ServerError;

import java.util.HashMap;
import java.util.Map;

public class CreateNetworkResponseForTesting {

    private static NetworkResponse createNetworkResponse(String responseBody, int statusCode){

        byte[] byteData = responseBody.getBytes();

        Map<String, String> headers = new HashMap<>();

        NetworkResponse networkResponse = new NetworkResponse(
                statusCode,
                byteData,
                headers,
                false);

        return networkResponse;

    }


    public static ServerError createServerNetworkResponse(String responseBody, int statusCode){

        Map<String, String> headers = new HashMap<>();

        NetworkResponse res = createNetworkResponse(responseBody, statusCode);

        ServerError newError = new ServerError(res);

        return newError;

    }

}
