package com.example.kinga.core.Urls;

import static com.example.kinga.core.Urls.SharedUrls.getBaseUrl;

public class TopUserUrlResolver {

    // Category urls  api/email-receipt/
    public static String categoryIndexUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/pos/categories/");
    }

    public static String categoryCreateUrl() {
        return categoryIndexUrl();
    }

    public static String categoryViewUrl(String reg_no) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/categories/edit/", reg_no);
    }

    // Discount urls
    public static String discountIndexUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/pos/discounts/", storeRegNo);
    }

    public static String discountCreateUrl(String storeRegNo) {
        return discountIndexUrl(storeRegNo);
    }

    public static String discountViewUrl(String storeRegNo, String discountRegNo) {
        return String.format("%s%s%s/edit/%s/", getBaseUrl(), "/api/pos/discounts/", storeRegNo, discountRegNo);
    }

    // Modifiers
    public static String modifierIndexUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/pos/modifiers/", storeRegNo);
    }

    // Products
    public static String productIndexUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/pos/products/", storeRegNo);
    }

    public static String productCreateUrl(String storeRegNo) {
        return productIndexUrl(storeRegNo);
    }

    public static String productViewUrl(String storeRegNo, String productRegNo) {
        return String.format("%s%s%s/edit/%s/", getBaseUrl(), "/api/pos/products/", storeRegNo, productRegNo);
    }

    public static String productImageViewUrl(String storeRegNo, String productRegNo) {
        return String.format("%s%s%s/edit/image/%s/", getBaseUrl(), "/api/pos/products/", storeRegNo, productRegNo);
    }

    // Tax urls
    public static String taxIndexUrl(String storeRegNo) {
        return String.format("%s%s%s/", getBaseUrl(), "/api/pos/taxes/", storeRegNo);
    }

    public static String taxCreateUrl(String storeRegNo) {
        return taxIndexUrl(storeRegNo);
    }

    public static String taxViewUrl(String storeRegNo, String taxRegNo) {
        return String.format("%s%s%s/edit/%s/", getBaseUrl(), "/api/pos/taxes/", storeRegNo, taxRegNo);
    }

    // Customer urls
    public static String tripIndexUrl() {
        return String.format("%s%s", getBaseUrl(), "/api/trips/");
    }

}
