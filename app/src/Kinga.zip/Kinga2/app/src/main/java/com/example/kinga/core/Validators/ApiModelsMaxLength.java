package com.example.kinga.core.Validators;

public class ApiModelsMaxLength {

    public static int sContactMessageTextMaxLength = 500;

    public static int sNameMaxLength = 50;

    public static int sUserFirstNameMaxLength = 15;
    public static int sUserLastNameMaxLength = 15;
    public static int sUserEmailMaxLength = 30;
    public static int sUserPhoneMaxLength = 12;
    public static int sUserLocationMaxLength = 30;
    public static int sUserBusinessNameMaxLength = 60;

    public static int sCommonNameMaxLength30 = 30;


    public static int sStoreNameMaxLength = 15;

    public static int sBillingAccountNoMaxLength = 20;
    public static int sBillingAmountMaxLength = 10;

    public static int sAmountMaxLength = 10;
    public static int sQuantityUnitsMaxLength = 8;





    public static int sTaxNameMaxLength = 30;
    public static int sDiscountNameMaxLength = 30;
    public static int sShiftCommentMaxLength = 30;
    public static int sCategoryNameMaxLength = 50;
    public static int sProductNameMaxLength = 50;

    public static int sCustomerNameMaxLength = 50;
    public static int sAddressMaxLength = 50;
    public static int sCityMaxLength = 50;
    public static int sRegionMaxLength = 50;
    public static int sPostalCodeMaxLength = 50;
    public static int sCountryMaxLength = 50;
    public static int sCustomerCodeMaxLength = 50;

    public static int sSkuMaxLength = 50;
    public static int sBarcodeMaxLength = 50;



    public static final int MAX_MODIFIER_DESCRIPTION_LIMIT = 38;
    public static final int MAX_SHIFT_COMMENT_LIMIT = 25;

















}
